var app = angular.module('starter', ['ngRoute']);
app.config(['$routeProvider', function($routeProvider) {
    $routeProvider.
    when('/detalles', {
            templateUrl: 'templates/detalles.html' // The ng-template id
        })
        .when('/menu', {
            templateUrl: 'templates/menu.html' // The ng-template id
        })
        .when('/suPedido', {
            templateUrl: 'templates/suPedido.html' // The ng-template id
        })
        .when('/enviar', {
            templateUrl: 'templates/formPedido.html', // The ng-template id
            controller: "formCtrl"
        })
        .when('/finalOrder', {
            templateUrl: 'templates/pedidoEnviado.html'
        })
}]);