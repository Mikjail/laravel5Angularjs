app.directive("slideArepas", function() {
    return {
        restrict: "E",
        templateUrl: "templates/arepas.html"
    }
});
app.directive("menu", function() {
    return {
        restrict: "E",
        templateUrl: "templates/menu.html"
    }
});
app.directive("detalles", function() {
    return {
        restrict: "E",
        templateUrl: "templates/detalles.html"
    }
});
app.directive("comprar", function() {
    return {
        restrict: "E",
        templateUrl: "templates/modal.html"
    }
});
app.directive("contacto", function() {
    return {
        restrict: "E",
        templateUrl: "templates/contacto.html"
    }
});
app.directive("map", function() {
    return {
        restrict: "E",
        templateUrl: "templates/map.html"
    }
});